# fpc_3_builder

* Uses a bootstrap compiler to compile the freepascal v3.0.0 source code, installs it and sets it as your default freepascal compiler.
* The bootstrap compiler and freepascal v3.0.0 source code are supplied in this repository (that is why git clone is slow!)
* You need at a Pi model with at least 512MB of RAM.
* __An internet connection is not required during the installation as all of the required files are supplied in this repository.__
