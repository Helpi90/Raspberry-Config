# no_swap

Disables the swapfile on your Raspberry Pi to extend flash media life. Useful for SD cards or USB memory sticks.
**Not recommended unless you have a Pi 2 or Pi 3, or if you use your Pi with a GUI interface!**

## Status

**Stable; ready for use**

## How do I install this?

* Run **install.sh** as root.

## Can I uninstall this?

* Run **uninstall.sh** as root.
