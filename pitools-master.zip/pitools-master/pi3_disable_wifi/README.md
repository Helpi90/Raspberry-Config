# pi3_disable_wifi

* Disables the Wi-fi controller on the Raspberry Pi 3

## Can I uninstall this?

Not yet (by hand only right now).
