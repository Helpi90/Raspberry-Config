# logs_to_ram

* Moves /tmp and /var/log to a small RAM disk
* /var/log will have all archived *.gz files flushed hourly

## Can I uninstall this?

Not yet (by hand only right now).
