# usb_current_boost

* Configures your Raspberry Pi to provide the maximum possible power from the USB ports.
* This only works on Pi 1 B+ and later and apparently will have no effect on the Pi 3 as it is enabled by default (reported on forums)
* Make sure you have a beefy PSU!

## Status

**Stable; ready for use but with care.**

## How do I install this?

* Just run **sudo ./install.sh**
* Reboot.
* Done!

## Can I uninstall this?

Not yet (by hand only right now).