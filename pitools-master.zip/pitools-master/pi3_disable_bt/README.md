# pi3_disable_bt

* Disables the Bluetooth controller on the Raspberry Pi 3
* This also means GPIO 14 and 15 can be used as a real hardware serial port again (UART0 / ttyAMA0)
* The bluetooth service is also disabled.

## Can I uninstall this?

Not yet (by hand only right now).
