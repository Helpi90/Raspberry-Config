#!/bin/sh
# Startup script for the autologin account
#
# Part of pitools - https://github.com/zipplet/pitools
# Copyright (c) Michael Nixon 2016.

# Put anything you want here.

./display_stats.sh
