#!/bin/bash
temp="$(/opt/vc/bin/vcgencmd measure_temp | sed 's/[^0-9.]*//g')"
printf "%.*f\n" 0 $temp

