# C O N N E C T I O N
#  The servo has three colors:
#    (1) brown  : GROUND
#    (2) orange : 5v
#    (3) yellow : output pin
#  I connected this way (the first time, it worked!!):
#    (1) brown  : GROUND     : pin 06
#    (2) orange : 5v         : pin 04
#    (3) yellow : output pin : pin 11
#    
# L I N K S
*bar controlling servo motors:
http://razzpisampler.oreilly.com/ch05.html


