# rpi_stuff
It collects all the stuff coming from any device
