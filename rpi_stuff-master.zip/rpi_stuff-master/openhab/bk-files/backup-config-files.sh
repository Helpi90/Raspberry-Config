
cp /etc/openhab/configurations/openhab.cfg /home/pi/git/rpi_stuff/openhab/bk-files/configurations/

cp -r /etc/openhab/configurations/items /home/pi/git/rpi_stuff/openhab/bk-files/configurations/
cp -r /etc/openhab/configurations/sitemaps /home/pi/git/rpi_stuff/openhab/bk-files/configurations/
cp -r /etc/openhab/configurations/scripts /home/pi/git/rpi_stuff/openhab/bk-files/configurations/
cp -r /etc/openhab/configurations/rules /home/pi/git/rpi_stuff/openhab/bk-files/configurations/
cp -r /etc/openhab/configurations/transform /home/pi/git/rpi_stuff/openhab/bk-files/configurations/

cp -r /usr/share/openhab/addons /home/pi/git/rpi_stuff/openhab/bk-files/share/
cp -r /usr/share/openhab/webapps/static /home/pi/git/rpi_stuff/openhab/bk-files/share/


